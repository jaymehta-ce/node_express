var http = require("http");
var fs = require('fs');
var port = 3000;
var serverUrl = "127.0.0.1";
var counter = 0;
var contentful = require('./contentful.js');
var express = require('express'),
    http = require('http'),
    request = require('request'),
    bodyParser = require('body-parser'),
    app = express();
	
app.set('port', process.env.PORT || 3001);	
app.get('/' , function(req,res) {
    res.sendfile('index.html');
});

app.get('/getdata', function(req,res){
	contentful.getRecords(req,res);
	
});
	
app.listen(app.get('port'), function () {
    console.log('Express server listening on port ' + app.get('port'));
});	
