
var contentful = require('contentful')
		var client = contentful.createClient({
		  // This is the space ID. A space is like a project folder in Contentful terms 
		  space: '36t7ny03afhb',
		  // This is the access token for this space. Normally you get both ID and the token in the Contentful web app 
		  accessToken: '1f1e6ff11efc5a2351f03451dfe0477ff583d67175cb26937f583d61d1ca94c7'
		})
		

module.exports = {
  getRecords: function(req, res) {    
        
		// This API call will request an entry with the specified ID from the space defined at the top, using a space-specific access token. 
		client.getEntry('4LgMotpNF6W20YKmuemW0a')
		.then(function (entry){ 
				
				console.log(entry);
				res.write(JSON.stringify(entry, null, "    "));
				res.end();
					
		})
		
	
		
	
  }
}